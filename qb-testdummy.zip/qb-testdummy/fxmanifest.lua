fx_version 'cerulean'
game 'gta5'

author 'KanliAy'
description 'Test Dummy'
version '1.0'

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}




