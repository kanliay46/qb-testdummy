local npcPed = nil
local targetHealth = 200 -- NPC'nin sağlığı, oyuncu sağlığına yakın bir değer (örneğin 200)
local targetArmor = 100 -- NPC'nin zırhı
local isShooting = false -- Ateş etme kontrolü

-- NPC'yi oluştur
RegisterNetEvent('spawnNPC')
AddEventHandler('spawnNPC', function(x, y, z)
    local playerPed = PlayerPedId()

    -- NPC modelini seç
    local model = "a_m_m_business_01" -- İstediğiniz NPC modelini buraya yazabilirsiniz
    RequestModel(model)
    
    -- Modelin yüklendiğinden emin olun
    while not HasModelLoaded(model) do
        Wait(500)
    end

    -- NPC'yi spawn et
    npcPed = CreatePed(4, model, x, y, z, 0.0, true, true)
    
    -- NPC başarılı bir şekilde oluşturulmuşsa
    if npcPed then
        -- NPC'nin özelliklerini ayarla
        SetEntityInvincible(npcPed, false) -- NPC'yi ölümsüz yapmayı kapat
        SetEntityHealth(npcPed, targetHealth) -- Sağlık ayarı (200 can)
        SetEntityMaxHealth(npcPed, targetHealth) -- Max sağlık da aynı olmalı
        SetPedArmour(npcPed, targetArmor) -- Zırh ayarı (100 zırh)

        FreezeEntityPosition(npcPed, true) -- NPC'yi freeze yap
        SetEntityVisible(npcPed, true, false) -- Görünürlük ayarı
        SetBlockingOfNonTemporaryEvents(npcPed, true) -- NPC'nin olaylara tepki vermesini engelle
        TaskStandStill(npcPed, -1) -- NPC'yi hareketsiz yap

        -- NPC'nin doğru spawn olduğuna dair bilgi ver
        exports['poly-notify']:sendnotify("NPC başarıyla spawn edildi!", "success")
    else
        exports['poly-notify']:sendnotify("NPC spawn edilemedi!", "error")
    end
end)

-- NPC'ye zırh ver
RegisterNetEvent('giveNPCArmor')
AddEventHandler('giveNPCArmor', function(armorAmount)
    if npcPed and DoesEntityExist(npcPed) then
        SetPedArmour(npcPed, armorAmount)
        targetArmor = armorAmount
        exports['poly-notify']:sendnotify("NPC'ye " .. armorAmount .. " zırh verildi!", "info")
    else
        exports['poly-notify']:sendnotify("NPC mevcut değil!", "error")
    end
end)

-- NPC'ye vurulduğunda bildirim göndermek
function shootAtNPC()
    local playerPed = PlayerPedId()
    local playerPos = GetEntityCoords(playerPed)
    local npcPos = GetEntityCoords(npcPed)
    
    if npcPed and DoesEntityExist(npcPed) then
        local dist = Vdist(playerPos.x, playerPos.y, playerPos.z, npcPos.x, npcPos.y, npcPos.z)
        
        -- Eğer oyuncu NPC'ye yakınsa ve atış yapıyorsa
        if dist < 10.0 then
            local weapon = GetSelectedPedWeapon(playerPed)
            
            -- Ateş etme kontrolü sadece bir kez yapalım
            if IsPedShooting(playerPed) and not isShooting then
                isShooting = true -- Ateş etme durumunu kontrol et
                local health = GetEntityHealth(npcPed)
                -- Atış yapıldığında NPC'nin sağlığını azalt
                SetEntityHealth(npcPed, health - 10)

                -- Bildirim gönder
                exports['poly-notify']:sendnotify("NPC'ye vuruldu! Kalan Sağlık: " .. (health - 10), "error")
            end
        end
    end
end

-- NPC'nin sağlığını kontrol et
function checkNPCHealth()
    if npcPed and DoesEntityExist(npcPed) then
        local health = GetEntityHealth(npcPed)

        -- NPC'nin sağlığı 0 veya altına düşerse
        if health <= 0 then
            exports['poly-notify']:sendnotify("Hedef öldü!", "success")
            DeleteEntity(npcPed)
            npcPed = nil
        end
    end
end

-- Ana döngü
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0) -- Hiç beklemeden her frame'de çalışsın

        -- NPC sağlığını kontrol et
        checkNPCHealth()

        -- NPC'ye vurulduğunda bildirim gönder
        shootAtNPC()

        -- Ateş etme durumunu sıfırlayalım
        if not IsPedShooting(PlayerPedId()) then
            isShooting = false
        end
    end
end)
