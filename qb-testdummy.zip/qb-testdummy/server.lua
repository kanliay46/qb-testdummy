RegisterCommand('spawnnpc', function(source, args, rawCommand)
    -- Komut ile NPC'yi spawn etme
    if #args < 3 then
        TriggerClientEvent('chat:addMessage', source, { args = { "Geçerli bir koordinat girin! (x, y, z)" } })
        return
    end

    local x, y, z = tonumber(args[1]), tonumber(args[2]), tonumber(args[3])
    
    -- Client'e NPC'yi spawn etmesini söyle
    TriggerClientEvent('spawnNPC', source, x, y, z)
    TriggerClientEvent('chat:addMessage', source, { args = { "NPC başarıyla spawn edildi!" } })
end, false)

RegisterCommand('givearmor', function(source, args, rawCommand)
    -- Komut ile NPC'ye zırh ver
    if #args < 1 then
        TriggerClientEvent('chat:addMessage', source, { args = { "Geçerli bir zırh miktarı girin!" } })
        return
    end

    local armorAmount = tonumber(args[1])
    
    -- Client'e NPC'ye zırh vermesini söyle
    TriggerClientEvent('giveNPCArmor', source, armorAmount)
    TriggerClientEvent('chat:addMessage', source, { args = { "NPC'ye " .. armorAmount .. " zırh verildi!" } })
end, false)
